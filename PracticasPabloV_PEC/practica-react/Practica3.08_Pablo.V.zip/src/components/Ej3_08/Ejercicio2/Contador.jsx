import React from 'react'

const Contador = (props) => {
    let dato = props.dato;
  return (
    <div>
      <h2>{dato}</h2>
    </div>
  )
}

export default Contador
