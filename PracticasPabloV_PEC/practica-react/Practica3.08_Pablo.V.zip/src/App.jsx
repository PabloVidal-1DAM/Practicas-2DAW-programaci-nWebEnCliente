import { useState } from 'react'
import './App.css'
import Listados from './components/Ej3_08/Ejercicio1/Listados.jsx'
import ContadorLimite from './components/Ej3_08/Ejercicio2/ContadorLimite.jsx';
import ContadorLikes from './components/Ej3_08/Ejercicio3/ContadorLikes.jsx';

function App() {

  return (
    <>
      {/*Ejercicio1:*/}
      {/*<Listados/>*/}

      {/*Ejercicio2:*/}
      {/*<ContadorLimite/>*/}

      {/*Ejercicio3:*/}
      <ContadorLikes/>
    </>
  );
}

export default App
