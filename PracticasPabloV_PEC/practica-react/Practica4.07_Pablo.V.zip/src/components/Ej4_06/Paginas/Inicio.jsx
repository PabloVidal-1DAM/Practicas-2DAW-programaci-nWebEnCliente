import React from "react";

const Inicio = () => {
  return (
    <div>
      <h1>Página de Inicio</h1>
    </div>
  );
};

export default Inicio;
