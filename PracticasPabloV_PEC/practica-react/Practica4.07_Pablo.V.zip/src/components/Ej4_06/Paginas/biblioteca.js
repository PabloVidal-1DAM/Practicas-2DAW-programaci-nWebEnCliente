"use strict";
// Función externa que comparten todas las páginas para volver a la de Inicio.
  const navegarInicio = (navigate) => {
    navigate("/");
  };

  export {navegarInicio};