import React from "react";
import Matriculados from "./Matriculados";

const Matricula = () => {
  return (
    <>
      <div>
        <h1>Listado Discentes</h1>
        <Matriculados />
      </div>
    </>
  );
};

export default Matricula;
