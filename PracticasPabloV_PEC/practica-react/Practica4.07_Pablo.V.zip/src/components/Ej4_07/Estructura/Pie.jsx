import React from 'react'
import "./Pie.css";

const Pie = () => {
  return (
    <div>
      <footer>
        <p>2025 App Películas | Pablo Vidal Ortega, Todos los derechos reservados.</p>
      </footer>
    </div>
  )
}

export default Pie
