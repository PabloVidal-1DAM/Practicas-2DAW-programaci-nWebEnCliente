import React from 'react'

const FiltrarTitulo = () => {
  return (
    <div>
      <h1>Se filtrará por titulo.</h1>
    </div>
  )
}

export default FiltrarTitulo
