import React from 'react'

const Inicio = () => {
  return (
    <div>
      <h1>Esta es la página de Inicio.</h1>
    </div>
  )
}

export default Inicio
