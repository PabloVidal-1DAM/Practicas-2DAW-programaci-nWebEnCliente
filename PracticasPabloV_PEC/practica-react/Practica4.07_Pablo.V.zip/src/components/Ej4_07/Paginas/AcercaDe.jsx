import React from 'react'

const AcercaDe = () => {
  return (
    <div>
      <h1>Esta es la página de Acerca de.</h1>
    </div>
  )
}

export default AcercaDe
