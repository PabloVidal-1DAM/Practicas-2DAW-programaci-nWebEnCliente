import React from 'react'

const FiltrarDirector = () => {
  return (
    <div>
      <h1>Se filtrará por Director.</h1>
    </div>
  )
}

export default FiltrarDirector
