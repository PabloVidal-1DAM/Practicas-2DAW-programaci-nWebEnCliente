import React from 'react'

const FiltrarInterprete = () => {
  return (
    <div>
      <h1>Se filtrará por Intérprete.</h1>
    </div>
  )
}

export default FiltrarInterprete
