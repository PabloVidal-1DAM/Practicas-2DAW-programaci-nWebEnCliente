import React from 'react'

const Error = () => {
  return (
    <div>
      <h1>Ha ocurrido un error, esta es la página de error</h1>
    </div>
  )
}

export default Error
