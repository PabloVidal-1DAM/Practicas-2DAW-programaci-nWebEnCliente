import React from "react";
import "./Cabecera.css";

const Cabecera = () => {
  return (
    <div>
      <header>
        <h1 className="h1_css">Formulario con persistencia</h1>
      </header>
    </div>
  );
};

export default Cabecera;
