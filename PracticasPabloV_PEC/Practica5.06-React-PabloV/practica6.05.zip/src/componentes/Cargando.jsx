import React from 'react'

const Cargando = () => {
  return (
    <>
        <h3>Cargando Datos</h3>
        <img src="https://media.tenor.com/6kYNH_1ry08AAAAi/hello.gif" height="445" width="345"/>
    </>
  )
}

export default Cargando
