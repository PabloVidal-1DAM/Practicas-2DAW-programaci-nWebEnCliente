import React from 'react'

const Inicio = () => {
  return (
    <div>
      <h1>Gestor de Discos de D.E.C</h1>
      <h3>Bienvenido.</h3>
    </div>
  )
}

export default Inicio
