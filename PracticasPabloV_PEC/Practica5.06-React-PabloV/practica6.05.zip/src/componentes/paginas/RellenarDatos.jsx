import React, { useContext, useEffect, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import Errores from "../Errores.jsx";
import useDiscos from "../../hooks/useDiscos.js";
import "./RellenarDatos.css";

// Elementos del prop de estados externos que gastará
// que son: La lista normal, la lista Filtrada y la lista con el elemento Borrado
const RellenarDatos = () => {
  const {
    listaDiscos,
    guardarDisco,
    discosEditados,
    editarDisco,
    filtrarDisco,
    cargando
  } = useDiscos();

  const navegar = useNavigate();
  const id = useParams();
  const formulario = document.forms.formularioDiscos;

  const valoresIniciales = {
    nombre: "",
    caratula: "",
    grupo: "",
    fechaPublicacion: "",
    genero: "",
    codigo: "",
    prestado: false,
  };

  // Estados internos que gastará este componente.
  const [disco, setDisco] = useState(valoresIniciales);

  const erroresIniciales = [];
  const [error, setError] = useState(erroresIniciales);

  useEffect(() => {
    if (discosEditados) {
      // Si el estado contiene un disco para editar, se carga su info en el formulario, con los valores por defecto si se dejasen nulos.
      setDisco({...valoresIniciales, ...discosEditados});
    } else {
      setDisco(valoresIniciales); // En caso contrario, es un disco nuevo.
    }
  }, [discosEditados]);

  // Se usa la desestructuración del target para ahorrar fatiga mental y entender mejor.
  // Se añade al estado "disco", la clave y el valor decada campo.
  const actualizarDatos = (evento) => {
    const { name, type, value, checked } = evento.target;
    setDisco({
      ...disco,
      [name]: type === "checkbox" ? checked : value,
    });
  };

  // Se valida cada parte del objeto JSON de discos bajo expresiones distintas dependiendo de que campo del objeto sea.
  const validarDato = (elemento) => {
    const { name, value } = elemento;
    // Todos los posibles errores que surgan irán aquí.
    let erroresElemento = [];

    if (name === "nombre" || name === "grupo") {
      const expresion = /^.{5,}$/;
      if (!expresion.test(value)) {
        erroresElemento = [
          ...erroresElemento,
          `Los campos nombre y grupo deben tener al menos 5 caracteres y son obligatorios.`,
        ];
      }
    } else if (name === "fechaPublicacion") {
      const expresion = /^\d{4}$/;
      if (!expresion.test(value)) {
        erroresElemento = [
          ...erroresElemento,
          "La fecha solo debe disponer de cuatro caracteres numéricos",
        ];
      }
    } else if (name === "genero") {
      if (!value.length) {
        erroresElemento = [...erroresElemento, "Debes seleccionar un género."];
      }
    } else if (name === "codigo") {
      const expresion = /^ES-\d{3}[A-Z]{2}$/;
      if (!expresion.test(value)) {
        erroresElemento = [
          ...erroresElemento,
          `Se debe seguir el formato ES-001AA donde 001 es el número de la estantería y AA la balda (combinación de dos letras mayúsculas).`,
        ];
      }
    }

    return erroresElemento;
  };

  const validarFormulario = (evento) => {
    let erroresListado = [];

    // En este aray se indican aquellos campos que sob obligatorios en el formnulario.
    const camposObligatorios = [
      "nombre",
      "grupo",
      "fechaPublicacion",
      "codigo",
    ];

    // Se recorre cada campo obligatorio para validarlos en la funcion "validarDato()";
    camposObligatorios.forEach((name) => {
      const elemento = formulario.elements[name];

      if (elemento) {
        // Se llama a validarDato que devuelve un array [].
        let erroresElemento = validarDato(elemento);

        // Se Aplican clases de estilo al elemento en caso de existir errores.
        if (erroresElemento.length > 0) {
          elemento.classList.add("error");
          erroresListado = [...erroresListado, ...erroresElemento];
        } else {
          elemento.classList.remove("error");
        }
      }
    });

    //En los radio button, como no es un input normal, sino una colección,
    // lo valido manualmente.
    const genero = formulario.elements["genero"].value;

    // Si no se selecciona ningún genero, nuevo error, debe de haber 1 seleccionado.
    if (!genero) {
      erroresListado = [...erroresListado, "Debes seleccionar un género."];
    }

    setError(erroresListado);
    // Devolverá true si el array de errores no contiene ningúno.
    return erroresListado.length === 0;
  };


  // Ya que el componente de la ruta /mostrar gasta la listaDiscos original, simplemente se navega a ese componente para enseñarlo.
  const borrarDisco = (formulario, ListadoDiscos) => {
    navegar("/mostrar");
  };

  return (
    <div>
      <form
        id="formulario"
        name="formularioDiscos"
        className="estiloFormulario"
      >
        <fieldset id="datosDiscos">
          <legend>Datos del disco</legend>
          <label htmlFor="nombre">Nombre del disco: </label>
          <input
            type="text"
            id="nombre"
            name="nombre"
            placeholder="Introduce el nombre del disco"
            value={disco.nombre}
            // Cada vez que cambie el valor, se llama a "actualizarDatos" para almacenar los datos del disco en el estado "disco"
            onChange={(evento) => {
              actualizarDatos(evento);
            }}
          />
          <br />
          <br />

          <label htmlFor="caratula">Carátula del disco: </label>
          <input
            type="url"
            id="caratula"
            name="caratula"
            placeholder="Introduce la URL de la caratula del disco"
            value={disco.caratula}
            onChange={(evento) => {
              actualizarDatos(evento);
            }}
          />
          <br />
          <br />

          <label htmlFor="grupo">Intérprete del disco: </label>
          <input
            type="text"
            id="grupo"
            name="grupo"
            placeholder="Introduce el grupo músical o intérprete del disco"
            value={disco.grupo}
            onChange={(evento) => {
              actualizarDatos(evento);
            }}
          />
          <br />
          <br />

          <label htmlFor="fechaPublicacion">fecha de publicación: </label>
          <input
            type="number"
            id="fechaPublicacion"
            name="fechaPublicacion"
            placeholder="Introduce el año de publicación"
            value={disco.fechaPublicacion}
            onChange={(evento) => {
              actualizarDatos(evento);
            }}
          />
          <br />
          <br />
        </fieldset>
        <br />
        <br />

        <fieldset id="generos">
          <legend>Género del disco</legend>
          <input
            type="radio"
            id="pop"
            name="genero"
            value="pop"
            checked={disco.genero === "pop"}
            onChange={(evento) => {
              actualizarDatos(evento);
            }}
          />
          <label htmlFor="pop">Pop</label>

          <input
            type="radio"
            id="contemporaneo"
            name="genero"
            value="contemporaneo"
            checked={disco.genero === "contemporaneo"}
            onChange={(evento) => {
              actualizarDatos(evento);
            }}
          />
          <label htmlFor="contemporaneo">Contemporáneo</label>

          <input
            type="radio"
            id="electronica"
            name="genero"
            value="electronica"
            checked={disco.genero === "electronica"}
            onChange={(evento) => {
              actualizarDatos(evento);
            }}
          />
          <label htmlFor="electronica">Electrónica</label>

          <input
            type="radio"
            id="rap"
            name="genero"
            value="rap"
            checked={disco.genero === "rap"}
            onChange={(evento) => {
              actualizarDatos(evento);
            }}
          />

          <label htmlFor="rap">Rap</label>
        </fieldset>
        <br />
        <br />

        <fieldset id="campoCodigo">
          <legend>Código del disco</legend>
          <label htmlFor="codigo">Código ISRC: </label>
          <input
            type="text"
            id="codigo"
            name="codigo"
            placeholder="Introduce el código"
            value={disco.codigo}
            onChange={(evento) => {
              actualizarDatos(evento);
            }}
          />
        </fieldset>
        <br />
        <br />

        <fieldset>
          <legend>Prestación</legend>
          <br />
          <label htmlFor="prestado">¿Está prestado?: </label>
          <input
            type="checkbox"
            id="prestado"
            name="prestado"
            checked={disco.prestado}
            onChange={(evento) => {
              actualizarDatos(evento);
            }}
          />
        </fieldset>
        <br />
        <br />

        <fieldset>
          <legend>Filtrar</legend>
          <br />
          <label htmlFor="filtrar">Filtrar:</label>
          <input
            type="text"
            id="filtrar"
            name="filtrar"
            placeholder="Filtrar por NOMBRE"
          />
        </fieldset>
        <br />
        <br />
        <div className="acciones">
          <input
            type="button"
            disabled = {cargando} // Se desabilita siempre que se hace una llamada a la API para evitar cagadas del usuario, ya la acción no se hace instantánea.
            value={cargando ? "Enviando datos... espera.": "Enviar Datos"}
            onClick={async (evento) => {
              // Si "validarFormulario" no devuelve errores, pasa la validación y se guarda en el estado "listaDiscos".
              if (validarFormulario(evento)) {
                if (disco.id){
                  await editarDisco(disco.id, disco)
                }else{
                  await guardarDisco(disco);
                }
                
                setDisco(valoresIniciales);
                setError([]);
              }
            }}
          />
          <input
            type="button"
            value="Filtrar"
            onClick={(evento) => {
              const formulario = document.forms.formularioDiscos;
              filtrarDisco(formulario, listaDiscos);
              // Al hacer click y filtrar el disco, se lleva automáticamente al componente <Disco> para que el usuario vea que se ha filtrado.
              navegar("/filtrado");
            }}
          />
          <input
            type="button"
            value="Borrar"
            onClick={(evento) => {
              const formulario = document.forms.formularioDiscos;
              borrarDisco(listaDiscos, formulario);
            }}
          />
        </div>
      </form>
      <br />
      <br />
      {/*Si el estado interno "error", contiene errores, entonces se muestra el componente "Errores.jsx"*/}
      {/*Al cual se le pasa el estado que almacena los errores para mostrarlos.*/}
      <div>{<div>{error.length > 0 && <Errores errores={error} />}</div>}</div>
    </div>
  );
};

export default RellenarDatos;
