import React from 'react'

const Inicio = () => {
  return (
    <div>
      
    </div>
  )
}

export default Inicio
