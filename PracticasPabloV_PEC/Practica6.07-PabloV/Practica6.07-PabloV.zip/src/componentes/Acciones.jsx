import React from 'react'

const Acciones = () => {
  return (
    <div>
      
    </div>
  )
}

export default Acciones
