import React from 'react'
import "./Pie.css";

const Pie = () => {
  return (
    <div>
      <footer>
        <p>2026 App Lista de la Compra | Pablo Vidal Ortega, Todos los derechos reservados.</p>
      </footer>
    </div>
  )
}

export default Pie
